/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiply;
import java.security.SecureRandom;
import java.util.Scanner;
/**
 *
 * @author Asus
 */
public class Multiply {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
      SecureRandom randomNumbers = new SecureRandom();

      int num1 = randomNumbers.nextInt(10);
      int num2 = randomNumbers.nextInt(10);
      

      System.out.println("How much is " + num1 + " times " + num2 + "?");

      boolean guessed=false;

      while(!guessed)
      {  
      int num3 = input.nextInt();
      
      if (num3 == num1 * num2)
      {
         int goodresponse = randomNumbers.nextInt(4);
         switch(goodresponse)
         {
            case 1:
            System.out.println("Very good!");
            break;
            case 2:
            System.out.println("Excellent!");
            break;
            case 3:
            System.out.println("Nice work!");
            break;
            case 4:
            System.out.println("Keep up the good work!");
            break;
            default:
            System.out.println("Very good!");
        }
         guessed = true;
      }
      else 
      {
         int badresponse = randomNumbers.nextInt(4);
         switch(badresponse)
         {
            case 1:
            System.out.println("No, please try again");
            break;
            case 2:
            System.out.println("Wrong. Try once more.");
            break;
            case 3:
            System.out.println("Don’t give up!");
            break;
            case 4:
            System.out.println("No. Keep trying.");
            break;
            default:
            System.out.println("No, please try again");
        }
         
         System.out.println("How much is " + num1 + " times " + num2 + "?");
      }
    }
    
}
}
