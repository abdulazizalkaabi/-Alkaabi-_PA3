
package problem.pkg2;

public class SavingsAccount {
    private static double annualInterestRate;
    private double savingsBalance;
    protected SavingsAccount()
    {
        savingsBalance = 0;
        annualInterestRate = 0;
    }
    protected SavingsAccount(double balance)
    {
        savingsBalance = balance;
        annualInterestRate = 0;
    }
    protected void calculateMonthlyInterest()
    {
        System.out.println("Current savings balance: " + savingsBalance);
        double monthlyInterest;
        monthlyInterest = (savingsBalance * annualInterestRate)/12;
        savingsBalance += monthlyInterest;
        System.out.println("New savings balance: " + savingsBalance);
    }
    protected double getBalance()
    {
        return savingsBalance;
    }
    protected static void modifyInterestRate(double newInterestRate)
    {
        annualInterestRate = newInterestRate;
    }   
}
