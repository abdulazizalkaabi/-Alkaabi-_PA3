/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiply;
import java.security.SecureRandom;
import java.util.Scanner;
/**
 *
 * @author Asus
 */
public class Multiply {

    /**
     * @param args the command line arguments
     */
        public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        SecureRandom randomNumbers = new SecureRandom();
        int questions=0;
        double correctanswer=0;
        int wronganswer=0;
        double percentage=0;
        boolean repeat=true;
        int num1,num2;

        while (repeat)
        {
        System.out.println("Welcome Student");
        System.out.println("Enter Difficulty 1-4");
        int difficulty= input.nextInt();
        System.out.println("Enter Choice 1-4");
        int choice = input.nextInt();
        
        while(questions<10)
        {   
            if (difficulty==1)
            {
            num1 = randomNumbers.nextInt(10);
            num2 = randomNumbers.nextInt(10);  
            }
            else if (difficulty==2)
            {
                num1 = randomNumbers.nextInt(100);
                num2 = randomNumbers.nextInt(100); 
            }
            else if (difficulty==3)
            {
                num1 = randomNumbers.nextInt(1000);
                num2 = randomNumbers.nextInt(1000); 
            }
            else
            {
                num1 = randomNumbers.nextInt(10000);
                num2 = randomNumbers.nextInt(10000);
            }
            if (choice==2)
            {
                System.out.println("How much is " + num1 + " times " + num2 + "?");
                int num3 = input.nextInt();
      
                if (num3 == num1 * num2)
                {
                    correctanswer++;
                    int goodresponse = randomNumbers.nextInt(4);
                     switch(goodresponse)
                    {
                        case 1:
                        System.out.println("Very good!");
                         break;
                        case 2:
                        System.out.println("Excellent!");
                         break;
                        case 3:
                        System.out.println("Nice work!");
                         break;
                        case 4:
                        System.out.println("Keep up the good work!");
                         break;
                        default:
                        System.out.println("Very good!");
                    }
                }
                else 
                {
                    wronganswer++;
                    int badresponse = randomNumbers.nextInt(4);
                    switch(badresponse)
                    {
                        case 1:
                        System.out.println("No, please try again");
                         break;
                        case 2:
                        System.out.println("Wrong. Try once more.");
                         break;
                        case 3:
                        System.out.println("Don’t give up!");
                         break;
                        case 4:
                        System.out.println("No. Keep trying.");
                         break;
                        default:
                        System.out.println("No, please try again");
                    }
                }
                questions++;
            }
            else if (choice==1)
            {
                System.out.println("How much is " + num1 + " Add " + num2 + "?");
                int num3 = input.nextInt();
      
                if (num3 == num1 + num2)
                {
                    correctanswer++;
                    int goodresponse = randomNumbers.nextInt(4);
                     switch(goodresponse)
                    {
                        case 1:
                        System.out.println("Very good!");
                         break;
                        case 2:
                        System.out.println("Excellent!");
                         break;
                        case 3:
                        System.out.println("Nice work!");
                         break;
                        case 4:
                        System.out.println("Keep up the good work!");
                         break;
                        default:
                        System.out.println("Very good!");
                    }
                }
                else 
                {
                    wronganswer++;
                    int badresponse = randomNumbers.nextInt(4);
                    switch(badresponse)
                    {
                        case 1:
                        System.out.println("No, please try again");
                         break;
                        case 2:
                        System.out.println("Wrong. Try once more.");
                         break;
                        case 3:
                        System.out.println("Don’t give up!");
                         break;
                        case 4:
                        System.out.println("No. Keep trying.");
                         break;
                        default:
                        System.out.println("No, please try again");
                    }
                }
                questions++;
            }
            else if (choice==3)
            {
                System.out.println("How much is " + num1 + " Subtract " + num2 + "?");
                int num3 = input.nextInt();
      
                if (num3 == num1 - num2)
                {
                    correctanswer++;
                    int goodresponse = randomNumbers.nextInt(4);
                     switch(goodresponse)
                    {
                        case 1:
                        System.out.println("Very good!");
                         break;
                        case 2:
                        System.out.println("Excellent!");
                         break;
                        case 3:
                        System.out.println("Nice work!");
                         break;
                        case 4:
                        System.out.println("Keep up the good work!");
                         break;
                        default:
                        System.out.println("Very good!");
                    }
                }
                else 
                {
                    wronganswer++;
                    int badresponse = randomNumbers.nextInt(4);
                    switch(badresponse)
                    {
                        case 1:
                        System.out.println("No, please try again");
                         break;
                        case 2:
                        System.out.println("Wrong. Try once more.");
                         break;
                        case 3:
                        System.out.println("Don’t give up!");
                         break;
                        case 4:
                        System.out.println("No. Keep trying.");
                         break;
                        default:
                        System.out.println("No, please try again");
                    }
                }
                questions++;
            }
            else
            {
                System.out.println("How much is " + num1 + " divide " + num2 + "?");
                int num3 = input.nextInt();
      
                if (num3 == num1 / num2)
                {
                    correctanswer++;
                    int goodresponse = randomNumbers.nextInt(4);
                     switch(goodresponse)
                    {
                        case 1:
                        System.out.println("Very good!");
                         break;
                        case 2:
                        System.out.println("Excellent!");
                         break;
                        case 3:
                        System.out.println("Nice work!");
                         break;
                        case 4:
                        System.out.println("Keep up the good work!");
                         break;
                        default:
                        System.out.println("Very good!");
                    }
                }
                else 
                {
                    wronganswer++;
                    int badresponse = randomNumbers.nextInt(4);
                    switch(badresponse)
                    {
                        case 1:
                        System.out.println("No, please try again");
                         break;
                        case 2:
                        System.out.println("Wrong. Try once more.");
                         break;
                        case 3:
                        System.out.println("Don’t give up!");
                         break;
                        case 4:
                        System.out.println("No. Keep trying.");
                         break;
                        default:
                        System.out.println("No, please try again");
                    }
                }
                questions++;
            }
        }
             percentage=(correctanswer/10)*100;
             System.out.println("You answered " + correctanswer + " times correct out of 10 ");
             System.out.println("You answered " + wronganswer + " times wrong out of 10 ");
             System.out.println("Your Percentage is : " + percentage);
            if (percentage>=75)
            {
                System.out.println("Congratulations, you are ready to go to the next level!");
            }
            else 
            {
                System.out.println("Please ask your teacher for extra help!");
            }
            questions=0;
        }
    }
}