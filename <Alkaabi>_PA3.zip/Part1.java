/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiply;
import java.security.SecureRandom;
import java.util.Scanner;
/**
 *
 * @author Asus
 */
public class Multiply {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
      SecureRandom randomNumbers = new SecureRandom();

      int num1 = randomNumbers.nextInt(10);
      int num2 = randomNumbers.nextInt(10);  

      System.out.println("How much is " + num1 + " times " + num2 + "?");

      boolean guessed=false;

      while(!guessed)
      {  
      int num3 = input.nextInt();
      
      if (num3 == num1 * num2)
      {
         System.out.println("Very Good!");
         guessed = true;
      }
      else 
      {
         System.out.println("No, please try again");
         System.out.println("How much is " + num1 + " times " + num2 + "?");
      }
    }
    
}
}